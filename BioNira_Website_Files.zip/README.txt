BioNira simple website

Files:
- index.html: the website home page

To preview:
1. Double-click index.html to open it in your browser.

To publish free with GitHub Pages:
1. Sign in to GitHub.
2. Create a new public repository named bionira-website.
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose branch main and folder /(root), then Save.
7. Wait for GitHub to show the published URL.

Important:
This site describes BioNira as a proposed research project only. It does not claim approval, certification, health benefits, or that a company is registered.
